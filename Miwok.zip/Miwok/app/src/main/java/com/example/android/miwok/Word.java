package com.example.android.miwok;

/**
 * Created by a on 08-May-17.
 */

public class Word {
    /** Default translation for the word*/
    private String mDefaultTraslation;
    /** Miwok transaltion for the word */
    private String mMiwokTransaltion;
    private int mImageResourceId = NO_IMAGE_PROVIDED;

    private static final int NO_IMAGE_PROVIDED = -1;

    public Word(String defaultTranslation, String miwokTranslation){
        mDefaultTraslation = defaultTranslation;
        mMiwokTransaltion = miwokTranslation;
    }

    public Word(String mDefaultTraslation, String mMiwokTransaltion, int mImageResourceId) {
        this.mDefaultTraslation = mDefaultTraslation;
        this.mMiwokTransaltion = mMiwokTransaltion;
        this.mImageResourceId = mImageResourceId;
    }

    public String getDefaultTranslation(){
        return mDefaultTraslation;
    }
    public String getMiwokTransaltion(){
        return mMiwokTransaltion;
    }
    public int getImageResourceId() {return mImageResourceId;}

    public boolean hasImage(){
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }
}
