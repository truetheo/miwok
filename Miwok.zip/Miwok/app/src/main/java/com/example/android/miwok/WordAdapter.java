package com.example.android.miwok;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by a on 08-May-17.
 */

public class WordAdapter extends ArrayAdapter<Word> {
    private static final String LOG_TAG = WordAdapter.class.getSimpleName();
    private int mColorResourceId;

    public WordAdapter(@NonNull Context context, @NonNull ArrayList<Word> words, int color) {
        super(context, 0, words);
        mColorResourceId = color;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if(listItemView == null) {


            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        //Here I know the position of the word in the ArrayAdapter to connect with resources
        Word currentWord = getItem(position);
        //Catch the view
        TextView defaultTranslationView = (TextView) listItemView.findViewById(R.id.word1);
        //TextView wil display the English Translation on the list (one after another)
        defaultTranslationView.setText(currentWord.getDefaultTranslation());
        TextView miwokTranslationView = (TextView) listItemView.findViewById(R.id.word2);
        miwokTranslationView.setText(currentWord.getMiwokTransaltion());
        ImageView miwokImage = (ImageView) listItemView.findViewById(R.id.image1);
        //NOw depanding of the hasImage method defined in the Word class. The hasImage
        //will hide the Image if the constructor was not populated with the image
        if(currentWord.hasImage()){
            miwokImage.setImageResource(currentWord.getImageResourceId());
            miwokImage.setVisibility(View.VISIBLE);
        } else{
            miwokImage.setVisibility(View.GONE);
        }
        //This line manages the background color of the LinearLayout.
        //Catch the view
        View textContainer = listItemView.findViewById(R.id.text_container);
        //The getContext passes the constructor Info and attaches the Color
        int color = ContextCompat.getColor(getContext(), mColorResourceId);
        textContainer.setBackgroundColor(color);
        return listItemView;
    }
}
