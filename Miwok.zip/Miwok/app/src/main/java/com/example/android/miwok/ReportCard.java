package com.example.android.miwok;

/**
 * Created by a on 09-May-17.
 */

public class ReportCard {
    private int mathGrade;
    private char polishGrade;

    /**
     * Constructor of the class
     * @param math uses the variable to create the instance of the class, the object.
     */
    public ReportCard(int math, char polish) {
            this.mathGrade = math;
            this.polishGrade = polish;
        }
    /**
     * Grade getter method. Allows to use student's grade.
     * @return the grade variable
     */
    public int getMathGrade(){
        return mathGrade;
    }

    /**
     * Grade setter method. Allows to change the student's grade.
     * @param number
     */
    public void setMathGrade(int number){
        if(number < 7 && number > 0){
            mathGrade = number;
        } else {
            mathGrade = 0;
        }

    }

    /**
     * Overrride of the toString method allows to see the string representation of the {@link ReportCard} object
     * @return human readable value.
     */

    public char getPolishGrade(){
        return polishGrade;
    }
    public void setPolishGrade(char polGrade){
        if(polGrade =='A' || polGrade == 'B' || polGrade == 'C' || polGrade == 'D' || polGrade=='F' ){
            polishGrade = polGrade;
        } else {
            polishGrade = 'F';
        }
    }

    /**
     * Override of the toString method to allow displaying human-readable string representing current status of the Object.
     * @return string of subjects and grades.
     */
    @Override
    public String toString() {
        return "Known grades are:" +
                "{mathGrade:" + mathGrade +
                ", polishGrade:" + polishGrade +
                '}';
    }
}
